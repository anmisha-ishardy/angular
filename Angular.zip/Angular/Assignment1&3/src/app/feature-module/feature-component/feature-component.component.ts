import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-feature-component',
  templateUrl: './feature-component.component.html',
  styleUrls: ['./feature-component.component.css']
})
export class FeatureComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
