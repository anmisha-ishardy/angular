import { HighlightDirectiveDirective } from './highlight-directive.directive';

describe('HighlightDirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new HighlightDirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
