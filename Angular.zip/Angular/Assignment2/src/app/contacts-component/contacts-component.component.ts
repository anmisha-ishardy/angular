import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contacts-component',
  templateUrl: './contacts-component.component.html',
  styleUrls: ['./contacts-component.component.css']
})
export class ContactsComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}